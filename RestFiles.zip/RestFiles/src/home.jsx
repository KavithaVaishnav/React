import React from 'react';

const List = (props) => {
    console.log(props.pageList1)
        return(
          <div className="col-xs-8 listContainer">{
                props.pageList1.map(function(item, index){
                    return <div className="col-xs-4" key={index}>
                               <img className="ListItemImage col-xs-12" src={require("../src/Images/"+item["poster-image"])}/>
                               <span className="ListItemName col-xs-12">{item.name}</span>
                           </div>
                        
                })
               }
          </div>
        )
    }
export default List;