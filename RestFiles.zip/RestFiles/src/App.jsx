import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import ReactDOM from 'react-dom';
import {BrowserRouter, Route, Redirect, Switch} from 'react-router-dom';
import Routes from './route';
import List from './home';
    
class App extends Component {
    
    constructor(){
        super();
           this.changeHandler = this.changeHandler.bind(this);
           this.backButtonHandler = this.backButtonHandler.bind(this);
           this.searchHandler = this.searchHandler.bind(this);
        this.windowHeight = this.windowHeight.bind(this);
           this.state = {
              pageList1: [],
              data :require('./Json/CONTENTLISTINGPAGE-PAGE1.json'),
              searchType :"Romantic Comedy",
              height :null
            }  
    }
    backButtonHandler(){
        debugger;
         this.setState({ 
             pageList1 :[],
             searchType : ""
         });
    }
    changeHandler(e){
        debugger
         this.setState({
             searchType: e.target.value
         })
          if(e.target.value == "Romantic Comedy"){
              const pageList1 = this.state.data.page["content-items"].content;
              this.setState({ pageList1 })
        }else{
              this.setState({ 
              pageList1 :[],
         });
        }
    }
    searchHandler(e){
        if(this.state.searchType== "Romantic Comedy"){
            const pageList1 = this.state.data.page["content-items"].content;
           this.setState({ pageList1 })
        }else{
              this.setState({ 
             pageList1 :[],
         });
        }
    }
      componentDidMount(){
            debugger
       
        }
    componentWillMount(){
        debugger;
      console.log(this.state.data);
      const pageList1 = this.state.data.page["content-items"].content;
      this.setState({ pageList1 })
      console.log(pageList1);
      this.windowHeight();
     }
      windowHeight(){
        this.setState({height :90})
         window.addEventListener('scroll', this.handleScroll);   
      }
     componentWillUnmount() {
         window.removeEventListener('scroll', this.handleScroll);
     }
     
    handleScroll(event) {
        debugger;
      console.log(this.state.height)
    }
         
    render(){
     return(
     <div>
      <div className="MainContainer col-xs-12">
          <div className="search col-xs-8">
                <a href="#"><img className="backButton" src={require('./Images/Back.png')} onClick={this.backButtonHandler}/></a>
                <input type="Search" className="col-xs-12 searchBar" placeholder="" value={this.state.searchType} onChange={this.changeHandler}/>
                <img className="searchImage" src={require('./Images/search.png')} onClick={this.searchHandler}/>
          </div>
         <List pageList1={this.state.pageList1}></List>
      </div>
    </div>
     )
 }
}


export default App;
