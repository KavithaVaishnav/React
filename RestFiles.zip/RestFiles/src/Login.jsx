import React from 'react';
import {BrowserRouter,Link, Route, Redirect, Switch} from 'react-router-dom';
import Routes from './route';

const Login = (props) => {
        return (
           <div className="loginContainer col-xs-3">
              <label className="col-xs-12">UserName :</label>
               <div className="input-group">
                 <span className="input-group-addon"><i className="glyphicon glyphicon-user"></i></span>
                 <input type="text" placeholder="Enter name" name="username" className="col-xs-10 userName form-control" value={props.user} onChange={props.change}/>
                </div>
                
              <label className="col-xs-12 ">Password :</label>
              <div className="input-group">
                <span className="input-group-addon"><i className="glyphicon glyphicon-lock"></i></span>
                <input type="password"  placeholder="Enter Password" name="password" className="col-xs-6 password form-control" onChange={props.change} value={props.pass}/>
              </div>
                <BrowserRouter>
              <p className="col-xs-12"><button type="button" className="col-xs-6 btn btn-medium btn-success loginButton" onClick={props.loginHandler}><Link to={'/home'}>Login</Link></button></p>
                    </BrowserRouter>
            </div>
        )
}

export default Login;   